/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestiontransporteterrestre;

/**
 *
 * @author NACHO
 */
public class CamionCarga extends Vehiculo {
    private int capacidad;
    
    
    public CamionCarga(String patente, String marca, int anioFabricacion, int capacidad){
        super(patente, marca, anioFabricacion);
        if (capacidad < 1) capacidad = 1;
        if ( capacidad > 30) capacidad = 30;
        this.capacidad = capacidad;
    }
    @Override
    public int getCapacidad(){
        return capacidad;
    }
    
    @Override
    public void iniciarRecorrido(){
        System.out.println("Camion: " + patente + "Inicio el recorrido");
    }
    
    @Override
    public String toString(){
        return "Camion| patente: " + patente + "| marca: " + marca + "| Año: " + anioFabricacion + "| Carga: " + capacidad;
    }
    
}
