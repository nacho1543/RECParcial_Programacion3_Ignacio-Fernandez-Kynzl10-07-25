/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestiontransporteterrestre;

/**
 *
 * @author NACHO
 */
public class ColectivosPasajeros extends Vehiculo {
    private int CantidadPasajeros;
    
    public ColectivosPasajeros(String patente, String marca, int anioFabricacion, int CantidadPasajeros){
        super(patente, marca, anioFabricacion);
        this.CantidadPasajeros = CantidadPasajeros;
    }
    
    @Override
    public int getCapacidad() {
        return CantidadPasajeros;
        
    }
    
    @Override
    public void iniciarRecorrido(){
        System.out.println("Colectivo " + patente + "inicio el recorrido");
    }
    
    @Override
     public String toString(){
        return "Colectivo patente: " + patente + "| marca: " + marca + "| Año: " + anioFabricacion + "| Carga: " + CantidadPasajeros;
    }
}
