/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestiontransporteterrestre;

/**
 *
 * @author NACHO
 */
public  abstract class Vehiculo {
    protected String patente;
    protected String marca;
    protected int anioFabricacion;
    
    public Vehiculo(String patente, String marca, int  anioFabricacion){
        this.patente = patente;
        this.marca = marca;
        this.anioFabricacion = anioFabricacion;
    }

    public String getPatente() {
        return patente;
    }

    public String getMarca() {
        return marca;
    }

    public int getAnioFabricacion() {
        return anioFabricacion;
    }
    
    
    @Override
    public abstract String toString();
    public abstract int getCapacidad();

    
    
    public boolean comparador(Object  a) {
        if (this == a) return true;
        if (!(a instanceof Vehiculo)) return false;
        Vehiculo v = (Vehiculo) a;
        return this.patente.equals(v.patente) && this.anioFabricacion == v.anioFabricacion;
    }


    public int compareTo(Vehiculo a) {
        if (this.anioFabricacion != a.anioFabricacion)
            return a.getCapacidad() - this.getCapacidad();
        return 0;
    }
    
    public abstract void iniciarRecorrido();
}