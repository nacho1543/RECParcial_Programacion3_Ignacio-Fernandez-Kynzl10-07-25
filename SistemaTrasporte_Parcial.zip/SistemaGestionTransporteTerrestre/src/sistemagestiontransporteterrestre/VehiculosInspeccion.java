/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemagestiontransporteterrestre;

/**
 *
 * @author NACHO
 */
public class VehiculosInspeccion extends Vehiculo{
    private String UsoAsignado;
    
    
    public VehiculosInspeccion(String patente, String marca, int anioFabricacion, String UsoAsignado){
        super(patente, marca, anioFabricacion);
        this.UsoAsignado = UsoAsignado;
    }
    
    @Override
    public int getCapacidad(){
        return 0;
    }
    
    @Override
    public void iniciarRecorrido(){
        System.out.println("Vehiculo de ispeccion " + patente + "inicio el recorrido");
        
    }
    
    @Override
    public String toString() {
        return "Colectivo patente: " + patente + "| marca: " + marca + "| Año: " + anioFabricacion + "| Uso: " + UsoAsignado;
    }
}
