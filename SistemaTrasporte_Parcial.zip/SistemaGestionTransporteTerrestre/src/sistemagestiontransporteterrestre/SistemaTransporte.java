/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemagestiontransporteterrestre;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;


/**
 *
 * @author NACHO
 */


public class SistemaTransporte {
    private List<Vehiculo> vehiculos = new ArrayList<>();
    private Scanner sc = new Scanner(System.in);

    public void menu() {
        int op;
        do {
            System.out.println("\n--- MENÚ DE TRANSPORTE ---");
            System.out.println("1. Agregar vehículo");
            System.out.println("2. Mostrar todos los vehículos");
            System.out.println("3. Iniciar recorrido");
            System.out.println("4. Ordenar por marca");
            System.out.println("5. Ordenar por año");
            System.out.println("6. Ordenar por capacidad");
            System.out.println("7. Salir");
            System.out.print("Opción: ");
            op = Integer.parseInt(sc.nextLine());

            switch (op) {
                case 1 -> agregarVehiculo();
                case 2 -> mostrarVehiculos();
                case 3 -> iniciarRecorridos();
                case 4 -> ordenarPorMarca();
                case 5 -> ordenarPorAnio();
                case 6 -> ordenarPorCapacidad();
                case 7 -> System.out.println("Saliendo del sistema...");
                default -> System.out.println("Opción inválida.");
            }
        } while (op != 7);
    }

    private void agregarVehiculo() {
        try {
            System.out.println("\nTipo (1-Camión, 2-Colectivo, 3-Inspección): ");
            int tipo = Integer.parseInt(sc.nextLine());

            System.out.print("Patente: ");
            String patente = sc.nextLine();
            System.out.print("Marca: ");
            String marca = sc.nextLine();
            System.out.print("Año: ");
            int anio = Integer.parseInt(sc.nextLine());

            Vehiculo nuevo = null;
            switch (tipo) {
                case 1 -> {
                    System.out.print("Capacidad de carga (1-30): ");
                    int carga = Integer.parseInt(sc.nextLine());
                    nuevo = new CamionCarga(patente, marca, anio, carga);
                }
                case 2 -> {
                    System.out.print("Cantidad de pasajeros: ");
                    int pasajeros = Integer.parseInt(sc.nextLine());
                    nuevo = new ColectivoPasajeros(patente, marca, anio, pasajeros);
                }
                case 3 -> {
                    System.out.print("Uso asignado (MANTENIMIENTO/SUPERVISIÓN/EMERGENCIA): ");
                    String uso = sc.nextLine();
                    nuevo = new VehiculoInspeccion(patente, marca, anio, uso);
                }
                default -> {
                    System.out.println("Tipo inválido.");
                    return;
                }
            }

            if (!vehiculos.contains(nuevo)) {
                vehiculos.add(nuevo);
                System.out.println("Vehículo agregado correctamente.");
            } else {
                System.out.println("Vehículo ya registrado.");
            }
        } catch (Exception e) {
            System.out.println("Error al ingresar datos. Intente nuevamente.");
        }
    }

    private void mostrarVehiculos() {
        System.out.println("\n--- Vehículos registrados ---");
        if (vehiculos.isEmpty()) {
            System.out.println("No hay vehículos registrados.");
        } else {
            for (Vehiculo v : vehiculos) {
                System.out.println(v);
            }
        }
    }

    private void iniciarRecorridos() {
        System.out.println("\n--- Iniciando recorridos ---");
        for (Vehiculo v : vehiculos) {
            v.iniciarRecorrido();
        }
    }

    private void ordenarPorMarca() {
        vehiculos.sort(Comparator.comparing(Vehiculo::getMarca));
        mostrarVehiculos();
    }

    private void ordenarPorAnio() {
        Collections.sort(vehiculos);
        mostrarVehiculos();
    }

    private void ordenarPorCapacidad() {
        vehiculos.sort((v1, v2) -> v2.getCapacidad() - v1.getCapacidad());
        mostrarVehiculos();
    }

    public static void main(String[] args) {
        new SistemaTransporte().menu();
    }
}
