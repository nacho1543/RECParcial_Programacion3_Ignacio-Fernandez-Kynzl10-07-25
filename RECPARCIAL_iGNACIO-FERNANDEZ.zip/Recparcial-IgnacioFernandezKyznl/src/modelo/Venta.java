/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;

/**
 *
 * @author NACHO
 */
public class Venta  implements Serializable{
    private String origen;
    private String destino;
    private int cantidad;
    private int precioTotal;
    
    private static final int PRECIO_PASAJE = 250;
    
    
    public Venta(String origen, String destino, int cantidad){
         this.precioTotal = cantidad * PRECIO_PASAJE;
         this.cantidad = cantidad;
         this.destino = destino;
         this.origen = origen;
   
}

    public String getOrigen() {
        return origen;
    }

    public String getDestino() {
        return destino;
    }

    public int getCantidad() {
        return cantidad;
    }

    public int getPrecioTotal() {
        return precioTotal;
    }

    public static int getPRECIO_PASAJE() {
        return PRECIO_PASAJE;
    }  
}
