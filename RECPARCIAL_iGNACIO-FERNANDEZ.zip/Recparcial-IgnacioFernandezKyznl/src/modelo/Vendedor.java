/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;

/**
 *
 * @author NACHO
 */
public class Vendedor implements Serializable{
    private String usuario;
    private String pin;
    private int pasajesVendidos;
    
    public Vendedor(String usuario, String pin){
            this.usuario = usuario;
            this.pin = pin;
            this.pasajesVendidos = 0;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getpin() {
        return pin;
    }

    public int getPasajesVendidos() {
        return pasajesVendidos;
    }
    
    public void venderPasajes(int cantidad) {
        pasajesVendidos += cantidad;
    }
    
}
