/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;



import java.util.HashMap;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import modelo.Vendedor;
import modelo.Venta;
import persistencia.PersistenciaVendedores;
import javafx.scene.layout.VBox;
/**
 *
 * @author NACHO
 */
public class VentaView {
    
    public VentaView(Stage stage, Vendedor vendedor, HashMap<String, Vendedor> vendedores) {
        
        Label lblOrigen = new Label("Origen: ");
        TextField txtOrigen = new TextField();
        
        Label lblDestino = new Label("Destino: ");
        TextField txtDestino = new TextField();
        
        Label lblCantidad = new Label("Cantidad:");
        TextField txtCantidad = new TextField();
        
        Label lblResultado = new Label();
        
        Button btnConfirmar = new Button("Confirmar Venta");
        Button btnVolver = new Button("Volver al Menú");
        
        btnConfirmar.setOnAction(e->{
            String origen = txtOrigen.getText();
            String destino = txtDestino.getText();
            int cantidad;          
            try {
                cantidad = Integer.parseInt(txtCantidad.getText());
                if(cantidad > 0){
                    Venta venta = new Venta(origen, destino, cantidad);
                    vendedor.venderPasajes(cantidad);
                    PersistenciaVendedores.guardar(vendedores);
                    lblResultado.setText("Venta realizada. Total: $" + venta.getPrecioTotal());
                }else{
                    lblResultado.setText("Cantidad Invalida");
                }
            }catch(NumberFormatException ex) {
                lblResultado.setText("Debe ingresar un numero valido");
            }
           
        });
        btnVolver.setOnAction(e-> {
            new MenuView(stage, vendedor, vendedores);
        });
        
        VBox root = new VBox(5, lblOrigen, txtOrigen, lblDestino, txtDestino, lblCantidad, txtCantidad, lblResultado, btnVolver);
        root.setAlignment(Pos.CENTER);
      
        Scene scene = new Scene(root, 400, 400);
        stage.setTitle("Servicio de venta de pasajes");
        stage.setScene(scene);
        stage.show();
        
    }
    
}
