/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import java.util.HashMap;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import modelo.Vendedor;
import persistencia.PersistenciaVendedores;

/**
 *
 * @author NACHO
 */
public class LoginView {
    
    private HashMap<String, Vendedor> vendedores;
    private Vendedor usuarioLogueado;
    
    public LoginView(Stage stage) {
        vendedores = PersistenciaVendedores.cargar();
        
        Label lblUsuario = new Label("Usuario: ");
        TextField txtUsuario = new TextField();
        
        Label lblPin = new Label("PIN: ");
        TextField txtPin = new TextField();
        
        Button btnIngresar =  new Button("Ingresar");
        Label lblMensaje = new Label();
        
        btnIngresar.setOnAction(e->{
            String usuario = txtUsuario.getText();
            String Pin = txtPin.getText();
            
            if (vendedores.containsKey(usuario)){
                Vendedor vendedor =  vendedores.get(usuario);
                if (vendedor.getpin().equals(Pin)) {
                    usuarioLogueado = vendedor;
                    new MenuView(stage,usuarioLogueado, vendedores);
            }else {
                    lblMensaje.setText("PIN incorrecto");
                }
            }else{
                Vendedor nuevo = new Vendedor(usuario,Pin);
                vendedores.put(usuario, nuevo);
                PersistenciaVendedores.guardar(vendedores);
                usuarioLogueado = nuevo;
                new MenuView(stage, usuarioLogueado, vendedores);            
            }           
        });
        
        VBox root = new VBox(10, lblUsuario, txtUsuario, lblPin, txtPin, btnIngresar, lblMensaje);
        root.setAlignment(Pos.CENTER);
        root.setMinWidth(300);

        Scene scene = new Scene(root, 400, 300);
        stage.setTitle("Login - Sistema de Pasajes");
        stage.setScene(scene);
        stage.show();
        
        
        
    }
    
}
