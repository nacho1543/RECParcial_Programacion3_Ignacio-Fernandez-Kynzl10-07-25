/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import java.util.HashMap;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import modelo.Vendedor;
import persistencia.PersistenciaVendedores;

/**
 *
 * @author NACHO
 */
public class MenuView {
    
    public MenuView(Stage stage, Vendedor vendedor, HashMap<String, Vendedor> vendedores){
        
        Label lblBienvenido = new Label("Bienvenido: " + vendedor.getUsuario());
        
        Button btnVender = new Button("Vender Pasajes");
        Button btnConsultar = new Button("Consultar ventas");
        Button btnSalir = new Button("Cerrar sesion");
        
        btnVender.setOnAction(e->{
            new VentaView(stage, vendedor, vendedores);
            
        });
        
        
        btnConsultar.setOnAction(e->{
            Label lblVentas = new Label("Total de pasajes vendidos: " + vendedor.getPasajesVendidos());
            Button btnVolver = new Button("Volver al Menu");
            
            VBox vboxConsultar = new VBox(10, lblVentas, btnVolver);
            vboxConsultar.setAlignment(Pos.CENTER);
            Scene sceneConsultar = new Scene(vboxConsultar, 400, 400);
            stage.setScene(sceneConsultar);
            
            btnVolver.setOnAction(eh-> {
                new MenuView(stage, vendedor, vendedores);              
            });
        });
        
        btnSalir.setOnAction(e->{
            PersistenciaVendedores.guardar(vendedores);
            new LoginView(stage);
            
        });
        
        VBox root = new VBox(10, lblBienvenido, btnVender, btnConsultar, btnSalir);
        root.setAlignment(Pos.CENTER);
        
        Scene scene = new Scene(root, 400, 300);
        stage.setTitle("Menu Principal");
        stage.setScene(scene);
        stage.show();
                
    }
    
}
