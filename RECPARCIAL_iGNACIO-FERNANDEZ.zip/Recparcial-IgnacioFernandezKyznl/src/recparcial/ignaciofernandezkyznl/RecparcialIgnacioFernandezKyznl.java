/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package recparcial.ignaciofernandezkyznl;
import javafx.application.Application;
import javafx.stage.Stage;
import vista.LoginView;
/**
 *
 * @author NACHO
 */
public class RecparcialIgnacioFernandezKyznl  extends Application{

 
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage){
        new LoginView(primaryStage);   
    }   
}
