/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia;

import java.io.*;
import java.util.HashMap;
import modelo.Vendedor;

/**
 *
 * @author NACHO
 */
public class PersistenciaVendedores {
    private static  final String ARCHIVO = "vendedores.ser";
    
    public static void guardar(HashMap<String, Vendedor> vendedores) {
        try{
            FileOutputStream fileOut = new FileOutputStream(ARCHIVO);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(vendedores);
            out.close();
            fileOut.close();      
        } catch (IOException e) {
            
        }
    }
    public static HashMap<String, Vendedor> cargar() {
        HashMap<String, Vendedor> vendedores = new HashMap<>();
        try{
             FileInputStream fileIn = new FileInputStream(ARCHIVO);
            ObjectInputStream in = new ObjectInputStream(fileIn);
            vendedores = (HashMap<String, Vendedor>) in.readObject();
            in.close();
            fileIn.close();          
        }catch (IOException | ClassNotFoundException e) {           
            
        }
        return vendedores;
    }
    
    
    
}
