/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ar.edu.utn.fra.sistemapasajes.modelo;

/**
 *
 * @author Nacho
 */
public class Recorrido {
    public static double calcularDistancia(String origen, String destino){
        if((origen.equalsIgnoreCase("A") && destino.equalsIgnoreCase("B")) || (origen.equalsIgnoreCase("B") && destino.equalsIgnoreCase("A"))){
            return 70.5;
        } else if((origen.equalsIgnoreCase("B") && destino.equalsIgnoreCase("C")) || (origen.equalsIgnoreCase("C") && destino.equalsIgnoreCase("B"))){
            return 60;
        } else if((origen.equalsIgnoreCase("A") && destino.equalsIgnoreCase("C")) || (origen.equalsIgnoreCase("C") && destino.equalsIgnoreCase("A"))){
            return 120.7;
        }
        return 0;
    }
}
