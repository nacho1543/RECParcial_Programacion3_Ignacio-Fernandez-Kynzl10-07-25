/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ar.edu.utn.fra.sistemapasajes.modelo;

import java.io.Serializable;

/**
 *
 * @author Nacho
 */
public class PrecioPorTramo implements CalculadorPrecio, Serializable {
    private double precioPorKm;
    public PrecioPorTramo(double precioPorKm){
        this.precioPorKm = precioPorKm;
    }

    @Override
    public double calcularPrecio(String origen, String destino) {
        double distancia = Recorrido.calcularDistancia(origen, destino);
        return distancia * precioPorKm;
    }

}
