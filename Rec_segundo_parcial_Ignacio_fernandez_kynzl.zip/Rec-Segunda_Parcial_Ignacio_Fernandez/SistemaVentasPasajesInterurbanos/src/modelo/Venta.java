/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ar.edu.utn.fra.sistemapasajes.modelo;

import java.io.Serializable;

/**
 *
 * @author Nacho
 */
public class Venta implements Serializable {
    private String origen;
    private String destino;
    private PrecioFijo precioFijo;
    private PrecioPorTramo precioPorTramo;
    private int pasajes;

    public Venta(String origen, String destino, int pasajes) {
        this.origen = origen;
        this.destino = destino;
        this.precioFijo = precioFijo;
        this.pasajes = pasajes;
        this.precioPorTramo = precioPorTramo;
    }

    public String getOrigen() {
        return origen;
    }

    public String getDestino() {
        return destino;
    }

    public PrecioFijo getPrecioFijo() {
        return precioFijo;
    }

    public PrecioPorTramo getPrecioPorTramo() {
        return precioPorTramo;
    }

    public int getPasajes() {
        return pasajes;
    }
    
    @Override
    public String toString(){
        return "\nOrigen: " + origen + "\n Destino: " + destino + "\n Pasajes comprados: " + pasajes; 
    }
    
    
}
