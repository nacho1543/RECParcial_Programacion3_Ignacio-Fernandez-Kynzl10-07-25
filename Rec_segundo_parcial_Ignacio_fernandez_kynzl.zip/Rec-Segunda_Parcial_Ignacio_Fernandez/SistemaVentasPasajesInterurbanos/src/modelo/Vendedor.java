/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ar.edu.utn.fra.sistemapasajes.modelo;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Nacho
 */
public class Vendedor implements Serializable {
    private String usuario;
    private String pin;
    private ArrayList<Venta> ventas;
    
    public Vendedor(String usuario, String pin){
        this.usuario = usuario;
        this.pin = pin;
        this.ventas = new ArrayList<>();
        
    }
    
    public boolean validarPin(String input){
        return this.pin.equals(input);
    }

    public String getUsuario() {
        return usuario;
    }

    public String getPin() {
        return pin;
    }
    
    
    public void registrarVenta(String origen, String destino, int cantidadPasajes) {
       Venta venta = new Venta(origen, destino, cantidadPasajes);
        ventas.add(venta);
    }
    public int mostrarTodosPasajesVendidos(){
        int ventasTotales = 0;
        for(Venta venta : ventas){
            ventasTotales += venta.getPasajes();
        }
        return ventasTotales;
    }
    
    
    public ArrayList<Venta> getVentas() {
        return ventas;
    }
    
    public String mostrarVentas(){
        String str = "";
        for(Venta v: ventas){
            str += (v.toString()) + ("\n");
        }
        return str;
    }
}
