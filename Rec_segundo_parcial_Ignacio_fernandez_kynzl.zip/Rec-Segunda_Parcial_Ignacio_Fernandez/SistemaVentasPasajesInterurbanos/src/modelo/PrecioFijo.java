/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ar.edu.utn.fra.sistemapasajes.modelo;

import java.io.Serializable;

/**
 *
 * @author Nacho
 */
public class PrecioFijo implements CalculadorPrecio, Serializable {
    private double precio;
    
    public PrecioFijo(double precio) {
        this.precio = precio;
    }

    @Override
    
    public double calcularPrecio(String origen, String destino){
      return precio;
    }
    
   
        
    
}
