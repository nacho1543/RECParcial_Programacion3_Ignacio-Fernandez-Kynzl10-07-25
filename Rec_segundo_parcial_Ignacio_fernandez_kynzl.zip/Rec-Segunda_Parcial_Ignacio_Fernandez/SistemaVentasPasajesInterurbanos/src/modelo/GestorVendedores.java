/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ar.edu.utn.fra.sistemapasajes.modelo;

import ar.edu.utn.fra.sistemapasajes.modelo.Vendedor;
import ar.edu.utn.fra.sistemapasajes.persistencia.VendedoresData;
import java.util.HashMap;

/**
 *
 * @author Nacho
 */
public class GestorVendedores {
    private HashMap<String,  Vendedor> vendedores;
    private VendedoresData vendedoresData;
    
    
    public GestorVendedores(){
        vendedoresData = new VendedoresData();
        this.vendedores = VendedoresData.cargarArchivo();
    }

    public HashMap<String, Vendedor> getVendedores() {
        return vendedores;
    }
    public void agregarVendedores(Vendedor vendedor){
        vendedores.put(vendedor.getUsuario(), vendedor);
        vendedoresData.guardarArchivo(vendedores);
    }
    
    public Vendedor login(String usuario, String pin) {
        if(vendedores.containsKey(usuario)) {
            Vendedor vendedor = vendedores.get(usuario);
            if (vendedor.getPin().equals(pin)){
            return vendedor;
            }
        }
        return null;
    }

    public void guardarCambios() {
        VendedoresData.guardarArchivo(vendedores);
    }
    
}
