/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ar.edu.utn.fra.sistemapasajes.persistencia;

import ar.edu.utn.fra.sistemapasajes.modelo.Vendedor;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;

/**
 *
 * @author Nacho
 */
public class VendedoresData {
    private static final String ARCHIVO = "vendedores.data";
    
    public static void guardarArchivo(HashMap<String, Vendedor> vendedores){
         try (ObjectOutputStream oos = new ObjectOutputStream( new FileOutputStream(ARCHIVO))) {
            oos.writeObject(vendedores);
        } catch (IOException e) {
            System.out.println("Error guardando cuenta: " + e.getMessage());
        }
    }
    
    public static HashMap<String, Vendedor> cargarArchivo(){
        HashMap<String, Vendedor> vendedores = new HashMap<>();
          File archivo = new File(ARCHIVO);
        if (!archivo.exists()) {
            vendedores.put("Maria", new Vendedor("Maria", "1234"));
            vendedores.put("Jose", new Vendedor("Jose", "5678"));
            return vendedores;
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO))) {
            vendedores = (HashMap<String, Vendedor>) ois.readObject();
        }catch (IOException | ClassNotFoundException e){
            System.out.println("Error cargando cuenta: " + e.getMessage());
           vendedores.put("Mareiela", new Vendedor("Mariela", "1234"));
           vendedores.put("Josesito", new Vendedor("Josesito", "5678"));
            
        }
        return vendedores;
    }
}
