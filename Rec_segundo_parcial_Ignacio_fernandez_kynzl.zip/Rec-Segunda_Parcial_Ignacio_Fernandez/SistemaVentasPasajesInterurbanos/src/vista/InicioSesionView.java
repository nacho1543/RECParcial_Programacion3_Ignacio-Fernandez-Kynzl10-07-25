/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ar.edu.utn.fra.sistemapasajes.vista;

import ar.edu.utn.fra.sistemapasajes.modelo.Vendedor;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.util.HashMap;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


/**
 *
 * @author Nacho
 */
public class InicioSesionView extends VBox {
    public InicioSesionView(Stage stage, HashMap<String, Vendedor> vendedores) {
        
        setSpacing(10);
        setPadding(new javafx.geometry.Insets(20));
        
        Label lblUser = new Label("Nombre del vendedor: ");
        TextField campoTextoUsuario = new TextField();
        
        Label lblPin = new Label("Pin: ");
        PasswordField campoTextoPin = new PasswordField();
        
        Button btnIniciarSesion = new Button("Iniciar Sesíon");
        Label mensaje = new Label();
        
        btnIniciarSesion.setOnAction(e -> {
            String usuario = campoTextoUsuario.getText();
            String pin = campoTextoPin.getText();
            Vendedor vendedor = vendedores.get(usuario);            
        
            if (vendedor != null && vendedor.validarPin(campoTextoPin.getText())) {
                MenuView menu = new MenuView(stage, vendedor, vendedores);
                stage.setScene(new Scene(menu));
            } else {
                mensaje.setText("Usuario o PIN Incorrecto");
            }
        });
        
        getChildren().addAll(lblUser, campoTextoUsuario, lblPin, campoTextoPin, btnIniciarSesion, mensaje);
    }
    
}
