/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ar.edu.utn.fra.sistemapasajes.vista;

import ar.edu.utn.fra.sistemapasajes.modelo.CalculadorPrecio;
import ar.edu.utn.fra.sistemapasajes.modelo.GestorVendedores;
import ar.edu.utn.fra.sistemapasajes.modelo.PrecioFijo;
import ar.edu.utn.fra.sistemapasajes.modelo.PrecioPorTramo;
import ar.edu.utn.fra.sistemapasajes.modelo.Vendedor;
import java.util.HashMap;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author Nacho
 */
public class VentaView extends VBox{
    private double ultimoTotal;
    private GestorVendedores gestor;
    private Vendedor vendedor;
    private CalculadorPrecio precio;

    /**
     *
     * @param gestor
     * @param vendedor
     * @param vendedores
     */
    public VentaView(Stage stage, GestorVendedores gestor, Vendedor vendedor, HashMap<String, Vendedor> vendedores) {
        this.gestor = gestor;
        this.vendedor = vendedor;
        this.precio = new PrecioPorTramo(2.0);
        
    
        Label lblOrigen = new Label("Origen: ");
        TextField campoOrigen = new TextField();

        Label lblDestino = new Label("Destino: ");
        TextField campoDestino = new TextField();
        
        Label lblCantidad = new Label("C. pasajes: ");
        TextField campoCantidad = new TextField();
        

        Label lblResultado = new Label();

        Button btnRegistrar = new Button("Registrar venta");
        Button btnVolver = new Button("Volver");

        btnRegistrar.setOnAction(e -> {
            String origen = campoOrigen.getText();
            String destino = campoDestino.getText();
            int cantidad;

            try {
                cantidad = Integer.parseInt(campoCantidad.getText());
            } catch (NumberFormatException ex) {
                lblResultado.setText("Cantidad inválida.");
                return;
            }

            double precioUnitario = precio.calcularPrecio(origen, destino);
            double total = precioUnitario * cantidad;
            this.ultimoTotal = total;
            
            System.out.println("DEBUG >>> Total guardado en VentaView: " + this.ultimoTotal);

            vendedor.registrarVenta(origen, destino, cantidad);

            lblResultado.setText("Venta registrada. Total: $" + total);
        });
        
        btnVolver.setOnAction (e -> {
            MenuView menu = new MenuView(stage,  vendedor,  vendedores);
            stage.setScene(new Scene(menu));
        });
        
        
        
        
        getChildren().addAll(lblOrigen, campoOrigen, lblDestino, campoDestino, lblCantidad, campoCantidad, lblResultado, btnRegistrar, btnVolver);
    }    
    
    public double getUltimoTotal(){
        return ultimoTotal;
    }
    
}
