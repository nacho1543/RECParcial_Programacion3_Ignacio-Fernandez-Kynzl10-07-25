/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ar.edu.utn.fra.sistemapasajes.vista;

import ar.edu.utn.fra.sistemapasajes.modelo.GestorVendedores;
import ar.edu.utn.fra.sistemapasajes.modelo.Vendedor;
import java.util.HashMap;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.scene.layout.VBox;

/**
 *
 * @author Nacho
 */
public class MenuView extends VBox {
    private VentaView vista;
    private GestorVendedores gestor;

    public MenuView(Stage stage, Vendedor vendedor, HashMap<String, Vendedor> vendedores) {
        this.vista = new VentaView(stage, gestor, vendedor, vendedores);
        this.gestor = gestor;
        setSpacing(20);
        setPadding(new javafx.geometry.Insets(20));
        
        Label bienvenida = new Label("Bienvenido a la registradora de pasajes");
        
        Button btnVenta = new Button("Ventas");
        Button btnRegistro = new Button("Registrar Venta");

        Button btnSalir = new Button("Salir");
        
        btnVenta.setOnAction(e -> {
            Alert alerta = new Alert(Alert.AlertType.INFORMATION, "Ventas realizas del usuario: " + vendedor.mostrarVentas());
            alerta.showAndWait();
        });
        
        btnRegistro.setOnAction(e -> {
            stage.setScene(new Scene(vista));
        });
        
        btnSalir.setOnAction (e -> {
            InicioSesionView login = new InicioSesionView(stage, vendedores);
            stage.setScene(new Scene(login));
        });
        
        getChildren().addAll(bienvenida, btnVenta, btnRegistro, btnSalir);
        
    }

    


    
}
