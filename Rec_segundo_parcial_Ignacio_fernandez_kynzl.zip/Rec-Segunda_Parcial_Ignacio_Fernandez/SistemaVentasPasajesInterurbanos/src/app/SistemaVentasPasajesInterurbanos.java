/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ar.edu.utn.fra.sistemapasajes.app;

import ar.edu.utn.fra.sistemapasajes.modelo.Vendedor;
import ar.edu.utn.fra.sistemapasajes.persistencia.VendedoresData;
import ar.edu.utn.fra.sistemapasajes.vista.InicioSesionView;
import java.util.HashMap;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Nacho
 */
public class SistemaVentasPasajesInterurbanos extends Application {
    private HashMap <String, Vendedor> vendedores;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    /**
     * @param args the command line arguments
     */
    }
    @Override
    public void start(Stage primaryStage) throws Exception {
        vendedores = VendedoresData.cargarArchivo();
        
       InicioSesionView login = new InicioSesionView(primaryStage, vendedores);
        primaryStage.setScene(new Scene(login));
        primaryStage.setTitle("Menu - Inicio de sesión");
        
        // Guardar al salir
        primaryStage.setOnCloseRequest(e -> VendedoresData.guardarArchivo(vendedores));
        
        primaryStage.show();
    }
    
  
}